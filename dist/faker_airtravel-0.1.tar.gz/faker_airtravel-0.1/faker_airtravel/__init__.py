"""AirTravel Faker Community Provider"""

__version__ = '0.1'